let url= 'mongodb+srv://admin:adminhasmik1995@cluster0.486yc.mongodb.net/myDB?retryWrites=true&w=majority'


module.exports = url
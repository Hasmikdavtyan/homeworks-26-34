let url= 'mongodb+srv://admin:adminhasmik1995@cluster0.486yc.mongodb.net/myDBForPeople?retryWrites=true&w=majority'


module.exports = url


